H-LINK アイコン一式（ロゴは加工していません）

[Mac] H-LINK-mac.icns / app-icon-1024.png
[Windows] H-LINK-windows.ico / windows-tile-150,310.png
[iPhone・iPad] apple-touch-icon.png（ホーム画面に追加）
[Android・Chrome・Edge] icon-192/512.png / icon-maskable-512.png
[ブラウザのタブ] favicon.ico / favicon-16,32,48.png
[ストア・印刷] app-icon-1024.png（全面白地）/ app-icon-1024-rounded.png（角丸）
[透明背景] logo-mark-transparent.png
