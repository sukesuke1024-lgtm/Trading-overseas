H-LINK アイコン
app-icon-1024.png … アプリアイコン (1024x1024)
icon-512/192.png … PWA・ホーム画面
icon-maskable-512.png … Android 用（全面の白地）
apple-touch-icon.png … iOS ホーム画面
favicon.ico / favicon-16,32,48.png … ブラウザのタブ
browser-tab-sample.png … タブ表示の見本
logo-mark-transparent.png … 透明背景のロゴ
